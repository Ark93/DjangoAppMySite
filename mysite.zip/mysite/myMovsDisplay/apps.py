from django.apps import AppConfig


class MymovsdisplayConfig(AppConfig):
    name = 'myMovsDisplay'
