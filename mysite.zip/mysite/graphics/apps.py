from django.apps import AppConfig


class GraphicsConfig(AppConfig):
    name = 'graphics'
