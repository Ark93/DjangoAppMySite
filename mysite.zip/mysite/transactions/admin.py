from django.contrib import admin
from .models import Transaccion
# Register your models here.

admin.site.register(Transaccion)